<p align="center">
  <img src="assets/matrix-banner.svg" alt="Emmanuel KOUAME" width="100%">
</p>

<p align="center">
  <img src="assets/boot.svg" alt="Séquence de démarrage" width="100%">
</p>

<p align="center">
  <img src="assets/profile.svg" alt="Profil" width="100%">
</p>

<p align="center">
  <img src="assets/header-modules.svg" alt="Compétences" width="100%">
  <img src="assets/modules.svg" alt="Réseaux et adressage IPv4, DNS et services réseau, administration systèmes, notions de cybersécurité" width="100%">
</p>

<p align="center">
  <img src="assets/header-processes.svg" alt="Réalisations" width="100%">
</p>

<p align="center">
  <img src="assets/projects/pid-0001-adressage-ipv4-subnetting.svg" alt="Adressage IPv4 et subnetting" width="49%">
  <img src="assets/projects/pid-0002-dns-nslookup.svg" alt="DNS et nslookup" width="49%">
  <img src="assets/projects/pid-0003-veille-cybersecurite.svg" alt="Veille cybersécurité" width="49%">
</p>

<p align="center">
  <img src="assets/header-diagnostics.svg" alt="Diagnostic" width="100%">
  <img src="assets/diagnostics.svg" alt="Diagnostic" width="100%">
</p>

<p align="center">
  <img src="assets/contact.svg" alt="Contact" width="100%">
</p>

<p align="center">
  <a href="https://www.linkedin.com/in/kouame-emmanuel/">LinkedIn</a>
</p>
